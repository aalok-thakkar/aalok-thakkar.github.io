"""Score an autocorrect program on a data set.

Usage: python3 score.py SET_DIR COMMAND [ARG ...]

SET_DIR holds input.txt and expected.txt (and optionally labels.tsv for a
per-category breakdown). COMMAND is run with input.txt on standard input.

Example: python3 score.py dev ./autocorrect
"""

import collections
import os
import resource
import subprocess
import sys
import time

TIME_LIMIT = 60.0
MEMORY_LIMIT = 4 * 1024 ** 3


def read_lines(path):
    with open(path, encoding="utf-8") as f:
        return [line.strip() for line in f.read().splitlines()]


def run(command, input_path):
    """Run command on input_path. Return (stdout, seconds, exit code)."""
    with open(input_path, "rb") as stdin:
        start = time.monotonic()
        try:
            proc = subprocess.run(command, stdin=stdin, capture_output=True,
                                  timeout=TIME_LIMIT)
        except subprocess.TimeoutExpired:
            return None, time.monotonic() - start, None
        seconds = time.monotonic() - start
    return proc.stdout.decode("utf-8", "replace"), seconds, proc.returncode


def peak_memory_bytes():
    rss = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
    return rss if sys.platform == "darwin" else rss * 1024


def category_report(labels_path, outputs):
    """Print accuracy per category from labels.tsv."""
    hits = collections.Counter()
    totals = collections.Counter()
    with open(labels_path, encoding="utf-8") as f:
        next(f)
        for line, got in zip(f, outputs):
            _, expected, category, _ = line.rstrip("\n").split("\t")
            totals[category] += 1
            hits[category] += got == expected
    for category in sorted(totals):
        print(f"  {category:9s} {hits[category] / totals[category]:.4f} "
              f"({hits[category]}/{totals[category]})")


def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    set_dir, command = sys.argv[1], sys.argv[2:]
    expected = read_lines(os.path.join(set_dir, "expected.txt"))
    stdout, seconds, code = run(command, os.path.join(set_dir, "input.txt"))
    memory = peak_memory_bytes()

    if stdout is None:
        sys.exit(f"INVALID: exceeded {TIME_LIMIT:.0f} seconds")
    if code != 0:
        sys.exit(f"INVALID: exit status {code}")
    if memory > MEMORY_LIMIT:
        sys.exit(f"INVALID: used {memory / 1024 ** 3:.2f} GB of memory")
    outputs = [line.strip() for line in stdout.splitlines()]
    if len(outputs) != len(expected):
        sys.exit(f"INVALID: {len(outputs)} output lines, "
                 f"expected {len(expected)}")

    correct = sum(got == want for got, want in zip(outputs, expected))
    print(f"A = {correct / len(expected):.4f} ({correct}/{len(expected)})")
    print(f"T = {seconds:.2f} s")
    print(f"memory = {memory / 1024 ** 2:.0f} MB")
    labels = os.path.join(set_dir, "labels.tsv")
    if os.path.exists(labels):
        category_report(labels, outputs)


if __name__ == "__main__":
    main()
