Autocorrect hackathon: development set

Files
  dev/input.txt      2,000 words, one per line
  dev/expected.txt   the intended word for each line of input.txt
  dev/labels.tsv     input, expected word, category, edit distance
  score.py           scorer

Categories in labels.tsv
  human     a real misspelling written by a person
  keyboard  a typing slip
  correct   a correctly spelled word, to be returned unchanged

The hidden test set has the same format and the same three categories,
but its words are harder than these.

Scoring your program
  python3 score.py dev ./autocorrect

score.py prints your accuracy A, running time T and peak memory, with a
breakdown by category. It reports INVALID if the line count is wrong, the
program exits with an error, or the time or memory limit is exceeded.
